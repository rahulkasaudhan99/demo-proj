package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repository.RedisRepository;

@Service
public class RedisService {

	@Autowired
	RedisRepository repo;
	
	public String addProduct(Product product) {
		 repo.save(product);
		 return "Product added Sucessfull";
		 
	}
	 public Product getProductById(int Id) {
         return repo.getById(Id);
    }


}
