package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.service.RedisService;


@RestController
public class RedisController {

	@Autowired
	RedisService redisService;
	
	@GetMapping("/product/{id}")
    public Product getProduct(@PathVariable int id) {
        return redisService.getProductById(id);
    }
	
	@PostMapping("/product/add")
    public String addProduct(@RequestBody Product product) {
        return redisService.addProduct(product);
    }
}
